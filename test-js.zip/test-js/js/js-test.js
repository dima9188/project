$(document).ready(function (){

    $('#form').submit(function(){
        $('#form').validate({
            rules: {
                name: {
                    required: true,
                    minlength: 3,
                    maxlength: 55

                },
                phone:{
                    required: true,
                    number: true
                },
                file:{
                    required: true
                },
                sex:{
                    required: true
                }
            },
            messages: {
                name: {
                    required: "Поле 'Имя' обязательно к заполнению",
                    minlength: "Введите не менее 3-х символов в поле 'Имя'"
                },
                phone: {
                    required: "Поле 'Телефон' обязательно к заполнению"
                },
                file: {
                    required:"Поле 'Фото' обязательно к заполнению"
                },
                sex: {
                    required:"Поле 'Пол' обязательно к заполнению"
                }
            }
        });
        if (!$('#form').valid())
            return false;

        var row = '<tr class="new"><td>'+ $("input[name='name']").val() +'</td>';
        row += '<td>'+ $("input[name='phone']").val() +'</td>';
        row += '<td><img class="sec-image" height="150" width="150px" src="'+ $('.image').attr('src') +'" alt=""></td>';
        row += '<td>'+ $('select').val() +'</td>';
        row += '<td>'+ ($("input[type='checkbox']").is(":checked") ? 'true' : 'false') +'</td>';
        row += '<td><p class="rest">x</p></td>';
        row += '</tr>';
        $('table').append(row);
        $('tbody').show();
        $('.rest').click(function(){
            $(this).parent().parent().remove();
        });
        $('.image').hide();

        $('#form').trigger('reset');

        return false;

    });


});

function previewFile(){
    var preview = document.querySelector('.image'); //selects the query named img
    var file    = document.querySelector('input[type=file]').files[0]; //sames as here
    var reader  = new FileReader();

    reader.onloadend = function () {
        preview.src = reader.result;
       $('.image').css('display', 'block');
    };

    if (file) {
        reader.readAsDataURL(file); //reads the data as a URL
    } else {
        preview.src = "";
    }
}

