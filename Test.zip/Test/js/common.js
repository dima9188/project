$(document).ready(function (){


    $(".toggle-mnu").click(function() {
        $(this).toggleClass("on");
        $(".menu").slideToggle(600);
        return false;
    });


    $('.menu a').click(function(){
        if($(window).width() <= 767){
            $(".toggle-mnu").toggleClass("on");
            $(".menu").slideToggle(300);
        }

    });

    $(window).scroll(function(){
        $('.wrapper-menu').css('background', 'none');
        $('.logo').css({
            'margin-top': '35px',
            'padding-top': '0'
        });
        $('.menu').css({
            'margin-top': '45px',
            'padding-top': '0'

        });

        $('.toggle-mnu').css({
           'margin-top' : '40px'
        });
        if($(window).scrollTop()){
            $('.wrapper-menu').css({
                'background': 'rgba(108, 33, 25, 0.77)'
            });
            $('.logo').css({
                'margin-top': '0',
                'padding-top': '20px',
                'padding-bottom': '20px'
            });
            $('.menu').css({
                'margin-top': '0',
                'padding-top': '25px',
                'padding-bottom': '20px',

            });
            $('.toggle-mnu').css({
                'margin-top' : '26px'
            });
        }
    });

    $('.about-slider').owlCarousel({
        items : 4,
        navigation  : true,
        navText: "",
        loop : true,
        navSpeed : 1000,
        responsive : {
            0:{
                items : 1,
                nav : true
            },
            991:{
                items : 4,
                nav : true
            },
            768 : {
                items : 3,
                nav : true
            },
            480 : {
                items : 2,
                nav : true
            }
        }
    });


    $('.slide img').mouseenter(function(){
        $(this).siblings('.hid-block').show();
    });

    $('.hid-block').mouseleave(function(){
        $(this).hide();
    });


    $('.cont-wrapper .photo').mouseenter(function(){
        $(this).siblings('.hid-block2').show();
    });

    $('.hid-block2').mouseleave(function(){
        $(this).hide();
    });



    $('.works-page span').click(function(){
        var index = $(this).index();
        if($(".page-cont:eq("+index+")").css("display") == "block"){

        }
        else {
            $(".page-cont").hide();
            $(".page-cont:eq("+index+")").fadeIn("100");
        }
    });

    $(".page-cont:eq(0)").show();



    $(".works-page span:eq(0)").addClass('active');

    $(".works-page span").click(function() {
        $(".works-page span").removeClass("active");
        $(this).toggleClass("active");
    });


    $(".menu ul a").click(function () {
        elementClick = $(this).attr("href");
        destination = $(elementClick).offset().top - 70;
        $("html:not(:animated),body:not(:animated)").animate({scrollTop: destination}, 1300);
        return false;
    });




    $('.form_c').magnificPopup();

    $('#form').submit(function() {
        var modal = $(this);
        var message = $('.message');
        $.ajax({
            type: 'POST',
            url: 'send.php',
            data: modal.serialize(),
            success: function () {
                modal.trigger('reset');
                $.magnificPopup.close();
                message.show();
                function hid(){
                    message.hide();
                }
                setTimeout(hid, 2500);
            }
        });
        return false;
    });

    $('.message .close').click(function(){
        $('.message').hide();
    })

});


