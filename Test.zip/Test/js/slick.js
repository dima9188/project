//$(document).ready(function() {
//
//    $('.about-slider').slick({
//        autoplay: true,
//        arrows: true,
//        slidesToShow: 4,
//        slidesToScroll: 1,
//        infinite: true
//    });
//});