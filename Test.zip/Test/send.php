<?php

$to_email = '';
if (isset($_POST['name']))   {$username  = $_POST['name'];}

if (isset($_POST['phone']))  {$phone = $_POST['phone'];}
if (isset($_POST['email']))  {$email = $_POST['email'];}


// ОТПРАВЛЯЕМ СООБЩЕНИЕ
$subject = "Заявка с сайта ";

    $message = "Тема: Заказ обратного звонка!\nВаше имя: $username\nВаш e-mail: $email\nВаш телефон: $phone";
    $headers = "Content-type:text/html; charset=UTF-8\r\nFrom: 'Заказ оформлен через сайт'";

mail($to_email, $subject, $message, $headers) or die("Не могу отправить сообщение.");




